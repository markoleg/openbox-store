import LoginForm from '@/components/LoginForm/LoginForm';

export default function LoginPage() {
  return (
    <div>
      <h2>Login</h2>
      <LoginForm />
    </div>
  );
}